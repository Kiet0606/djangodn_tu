
package com.example.attendance

object Config {
    // Emulator: http://10.0.2.2:8000/ ; Thiết bị thật: http://<IP LAN>:8000/
    const val BASE_URL: String = "http://10.0.2.2:8000/"
}
